# Recruitment Platform — Technology Stack

## 1. Recommended Architecture

Use a three-layer full-stack architecture:

Frontend -> REST API Backend -> MySQL Database

The backend owns:
- Authentication
- Authorization
- Validation
- Deadline enforcement
- Business rules
- Database access
- Application status changes

The frontend owns:
- User interface
- Client-side validation
- API interaction
- Loading/error/success presentation
- Navigation

The database owns:
- Persistent records
- Relationships
- Constraints
- Indexes

## 2. Frontend

### Core
- React
- TypeScript
- Vite

### Styling
Recommended:
- Tailwind CSS

Alternative:
- CSS Modules or standard CSS

### Routing
- React Router

### API
- Native Fetch API or Axios

### Forms
- React Hook Form
- Zod for client-side schema validation

### UI/Feedback
- Toast notification library such as Sonner
- Accessible modal/dialog component
- Skeleton/loading components

## 3. Backend

Recommended:
- Node.js
- TypeScript
- Express.js

Supporting packages:
- `bcrypt` or Argon2 implementation for password hashing
- `jsonwebtoken` if JWT authentication is selected
- `express-session` if server-side sessions are selected
- `zod` or `express-validator` for validation
- `helmet` for security headers
- `cors`
- `express-rate-limit`
- `dotenv`

## 4. Database

### Primary recommendation
MySQL

ORM:
- Prisma

Prisma provides:
- Schema management
- Migrations
- Type-safe queries
- Relations
- Database constraints
- Index definitions

## 5. Authentication

Preferred approach:
- Secure HTTP-only cookie-based sessions.

Alternative:
- Short-lived access JWT + secure refresh-token architecture.

Regardless of implementation:
- Never trust client-provided role information.
- Never store plaintext passwords.
- Backend middleware must validate authentication before protected routes.
- Backend middleware must validate authorization before role-specific routes.

## 6. Development Tools

- Git
- GitHub
- VS Code
- Postman or Insomnia
- MySQL Workbench
- Browser DevTools

## 7. Testing

Recommended:
- Vitest/Jest for frontend/backend unit tests.
- Supertest for backend API testing.
- Playwright for critical end-to-end flows.

Minimum critical tests:
- Registration
- Login
- Invalid login
- Protected endpoint without authentication
- Student accessing admin endpoint
- Admin access
- Application creation
- Duplicate application
- Deadline enforcement
- Status update authorization

## 8. Deployment

Possible architecture:
- Frontend: Vercel/Netlify
- Backend: Render/Railway/Fly.io or equivalent
- MySQL: managed MySQL provider

Production secrets must be supplied through environment variables.

## 9. Environment Variables

Example:

```env
DATABASE_URL=
SESSION_SECRET=
JWT_SECRET=
FRONTEND_URL=
NODE_ENV=
PORT=
```

Only variables actually required by the chosen architecture should be included.

## 10. Suggested Project Structure

```text
recruitment-platform/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── layouts/
│   │   ├── hooks/
│   │   ├── services/
│   │   ├── schemas/
│   │   ├── types/
│   │   └── utils/
│   ├── public/
│   └── package.json
│
├── backend/
│   ├── src/
│   │   ├── controllers/
│   │   ├── routes/
│   │   ├── middleware/
│   │   ├── services/
│   │   ├── repositories/
│   │   ├── validators/
│   │   ├── utils/
│   │   └── app.ts
│   ├── prisma/
│   │   └── schema.prisma
│   └── package.json
│
├── docs/
├── .env.example
├── .gitignore
└── README.md
```

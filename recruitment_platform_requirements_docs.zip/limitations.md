# Limitations and Constraints

## 1. Project Scope

This project is intended as a college recruitment platform, not a complete enterprise HR/recruitment product.

The architecture should demonstrate correct engineering principles without unnecessary complexity.

## 2. Authentication Limitations

The initial version may support only:
- Email/password authentication
- Student and admin roles

OAuth, SSO, biometric authentication and institutional identity providers are outside the mandatory scope.

## 3. Email

Email confirmation is optional.

If implemented as a mock feature, the system may simulate sending email rather than using a real production mail provider.

## 4. Real-Time Updates

Real-time status updates are optional.

Polling can be used as a simpler alternative.

Socket.io/WebSockets are not mandatory.

## 5. Analytics

Analytics are optional.

The core project only requires recruitment and application management.

If analytics are added, they should be based on actual database records rather than hardcoded values.

## 6. File Uploads

Resume/document upload is not required by the provided brief.

If implemented later, it introduces additional concerns:
- File type validation
- File size limits
- Storage
- Malware scanning
- Access control
- Secure download URLs

## 7. Scale

The initial system targets college/society recruitment rather than millions of users.

Nevertheless, the application should avoid obviously inefficient patterns such as fetching the entire database for every search.

## 8. Database Choice

The mandatory requirement allows MySQL or MongoDB.

The recommended implementation uses MySQL because applications naturally connect students and societies through relationships.

Switching database technology later would require repository/schema changes.

## 9. Security Scope

The project should implement meaningful basic security but is not a replacement for a professional security audit.

Production deployment would require additional controls such as:
- HTTPS enforcement
- Security monitoring
- Centralized logging
- Secret rotation
- Backup strategy
- Disaster recovery
- Advanced abuse detection
- Vulnerability scanning

## 10. Admin Provisioning

A controlled method for creating the first admin account is required.

The project should not allow arbitrary users to register themselves as administrators.

## 11. Status Workflow

The basic status model is:
- Pending
- Accepted
- Rejected

More complex workflows such as interview rounds, waitlists, withdrawals and multiple selection stages are outside the mandatory scope.

## 12. Concurrent Applications

Basic database constraints should prevent duplicate applications.

More advanced distributed concurrency handling is outside the expected scope unless required by deployment scale.

## 13. Third-Party Services

External services are optional and should not be required for the basic demonstration.

The core platform should work locally with:
- Frontend
- Backend
- MySQL database

## 14. Network Dependency

The frontend requires backend connectivity for authenticated operations.

Offline application submission is not part of the scope.

## 15. Browser Support

The target is modern browsers such as:
- Chrome
- Edge
- Firefox
- Safari

Legacy browsers are not a target.

## 16. Data Privacy

The platform may contain student personal information. A real deployment should define:
- Data retention rules
- Privacy policy
- Access policies
- Data deletion process
- Administrative audit controls

These are beyond the minimum technical challenge but should be considered before production use.

# Project Data Model

## 1. Overview

The platform uses a relational data model.

Core relationship:

```text
Student/User 1 ───────< Application >─────── 1 Society
```

One student can submit multiple applications.

One society can receive multiple applications.

Each application belongs to one student and one society.

## 2. Entity: Users

Suggested table:

```text
users
```

Fields:

| Field | Type | Purpose |
|---|---|---|
| id | UUID/BIGINT | Primary key |
| name | VARCHAR | Student/admin name |
| email | VARCHAR | Unique login email |
| password_hash | VARCHAR | Hashed password |
| role | ENUM | STUDENT / ADMIN |
| created_at | DATETIME | Creation time |
| updated_at | DATETIME | Last update |

Constraints:
- `id` primary key
- `email` unique
- `password_hash` required
- `role` restricted to valid roles

Never store:
```text
password
```

Store:
```text
password_hash
```

## 3. Entity: Societies

Suggested table:

```text
societies
```

Fields:

| Field | Type | Purpose |
|---|---|---|
| id | UUID/BIGINT | Primary key |
| name | VARCHAR | Society name |
| description | TEXT | Society description |
| category | VARCHAR | Society category |
| deadline | DATETIME | Recruitment deadline |
| is_active | BOOLEAN | Recruitment availability |
| eligibility | TEXT | Eligibility information |
| created_at | DATETIME | Creation time |
| updated_at | DATETIME | Last update |

Optional:
- logo_url
- contact_email
- recruitment_instructions

## 4. Entity: Applications

Suggested table:

```text
applications
```

Fields:

| Field | Type | Purpose |
|---|---|---|
| id | UUID/BIGINT | Primary key |
| student_id | FK | References users |
| society_id | FK | References societies |
| answers | JSON/TEXT | Application answers |
| status | ENUM | Pending/Accepted/Rejected |
| submitted_at | DATETIME | Submission time |
| updated_at | DATETIME | Last status/update time |

Relationships:
```text
applications.student_id -> users.id
applications.society_id -> societies.id
```

Constraint:
```text
UNIQUE(student_id, society_id)
```

This prevents the same student from submitting multiple applications to the same society.

## 5. Optional Entity: Audit Logs

For stronger ownership:

```text
audit_logs
```

Fields:
- id
- actor_user_id
- action
- entity_type
- entity_id
- old_value
- new_value
- created_at

Useful for tracking:
- Society changes
- Application status changes
- Admin actions

## 6. Indexing Strategy

Recommended indexes:

### Users
```text
UNIQUE(email)
INDEX(role)
```

### Societies
```text
INDEX(category)
INDEX(deadline)
INDEX(is_active)
```

### Applications
```text
UNIQUE(student_id, society_id)
INDEX(student_id)
INDEX(society_id)
INDEX(status)
INDEX(submitted_at)
```

Composite indexes can be added based on real query patterns.

For example, if admins frequently query applications by society and status:

```text
INDEX(society_id, status)
```

## 7. Query Examples

### Student's applications

```sql
SELECT *
FROM applications
WHERE student_id = ?
ORDER BY submitted_at DESC;
```

### Applicants for society

```sql
SELECT a.*, u.name, u.email
FROM applications a
JOIN users u ON u.id = a.student_id
WHERE a.society_id = ?
ORDER BY a.submitted_at DESC;
```

### Filter by status

```sql
SELECT a.*, u.name, u.email
FROM applications a
JOIN users u ON u.id = a.student_id
WHERE a.society_id = ?
AND a.status = ?;
```

### Search applicant

```sql
SELECT a.*, u.name, u.email
FROM applications a
JOIN users u ON u.id = a.student_id
WHERE a.society_id = ?
AND (u.name LIKE ? OR u.email LIKE ?);
```

The application should use parameterized queries/ORM query methods rather than string-concatenating user input into SQL.

## 8. Deadline Logic

When submitting:

```text
Current server time < Society deadline
        |
        +-- YES -> continue
        |
        +-- NO -> reject application
```

The client cannot override this rule.

## 9. Application State

Initial:
```text
Pending
```

Admin may update:
```text
Pending -> Accepted
Pending -> Rejected
```

Additional transitions can be defined if the product requirements expand.

## 10. Data Integrity Rules

- Application must reference an existing student.
- Application must reference an existing society.
- Student must be authenticated before applying.
- Society must be active/open for applications.
- Deadline must not have passed.
- Duplicate application must be rejected.
- Status must be one of the allowed values.
- Admin-only changes must be authorized.

## 11. Data Lifecycle

### Registration
Create user.

### Society creation
Admin creates society.

### Application
Student creates application.

### Review
Admin reads application.

### Decision
Admin changes status.

### Student tracking
Student reads own application status.

## 12. Data That Must Never Be Exposed

Do not return:
- Password hashes
- Authentication secrets
- Database credentials
- Session secrets
- JWT signing secrets
- Internal stack traces

## 13. Example Data

### User

```json
{
  "id": "student-001",
  "name": "Example Student",
  "email": "student@example.com",
  "role": "STUDENT"
}
```

### Society

```json
{
  "id": "society-001",
  "name": "Tech Society",
  "category": "Technical",
  "deadline": "2026-10-20T23:59:59Z",
  "is_active": true
}
```

### Application

```json
{
  "id": "application-001",
  "student_id": "student-001",
  "society_id": "society-001",
  "status": "Pending",
  "answers": {
    "why_join": "Interested in building software projects."
  }
}
```

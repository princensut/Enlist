# Product Requirements Document (PRD)

# College Society Recruitment Platform

## 1. Product Summary

The College Society Recruitment Platform is a full-stack web application that digitizes student recruitment for college societies.

Students can discover societies, authenticate, submit applications and track their application status.

Administrators can create and manage societies, view applicants and update application decisions.

The product is designed specifically to demonstrate full-stack engineering ability through real authentication, authorization, persistent storage, relational data modeling, validation, database querying and user experience.

---

# 2. Problem Statement

Traditional society recruitment may rely on disconnected forms, spreadsheets, manual filtering and communication.

This creates problems such as:
- Fragmented applicant information
- Difficulty tracking application status
- Manual society management
- Limited access control
- Duplicate applications
- Weak deadline enforcement
- Poor visibility for students
- Inefficient applicant filtering

The platform centralizes the recruitment workflow.

---

# 3. Product Objectives

## Primary Objectives

1. Provide secure student authentication.
2. Allow students to apply to societies.
3. Allow students to track application status.
4. Allow administrators to manage societies.
5. Allow administrators to review applicants.
6. Persist all important data.
7. Enforce authorization at the backend.
8. Enforce deadlines at the backend.
9. Provide database-backed search and filtering.
10. Provide clear interactive UI feedback.

---

# 4. Target Users

## Student

A college student who wants to discover and apply to societies.

Needs:
- Simple registration
- Secure login
- Society discovery
- Clear application forms
- Application tracking
- Status visibility

## Administrator

A society/college recruitment administrator.

Needs:
- Society management
- Applicant management
- Search/filtering
- Status management
- Recruitment overview

---

# 5. User Stories

## Student Stories

### Registration
As a student, I want to create an account so that I can apply to societies.

### Login
As a student, I want to securely log in so that my applications are private.

### Browse
As a student, I want to see available societies so that I can choose where to apply.

### Details
As a student, I want to see society details and deadlines before applying.

### Apply
As a student, I want to submit an application so that the society can review me.

### Track
As a student, I want to see whether my application is Pending, Accepted or Rejected.

### Privacy
As a student, I want only my own applications to be visible to me.

## Admin Stories

### Society Creation
As an admin, I want to create societies so that recruitment opportunities can be published.

### Society Editing
As an admin, I want to edit society information so that recruitment details remain accurate.

### Society Deletion
As an admin, I want to remove societies when recruitment is no longer active, subject to business rules.

### Applicant Review
As an admin, I want to view applicants for a society so that I can review applications.

### Search
As an admin, I want to search applicants so that I can find candidates efficiently.

### Filter
As an admin, I want to filter applicants by status/category/society so that I can manage recruitment efficiently.

### Status
As an admin, I want to update an application status so that students know their recruitment outcome.

---

# 6. Functional Scope

## Authentication

Required:
- Registration
- Login
- Logout
- Current-user endpoint/session validation
- Password hashing
- Authentication middleware

## Authorization

Required:
- STUDENT role
- ADMIN role
- Student-only routes
- Admin-only routes
- Backend authorization

## Society Management

Required:
- Create
- Read
- Update
- Delete

## Application Management

Required:
- Create
- Read own applications
- Admin read all relevant applications
- Update status

---

# 7. Non-Functional Requirements

## Security

The application must:
- Hash passwords.
- Protect authentication state.
- Validate backend requests.
- Enforce authorization.
- Protect secrets.
- Prevent unauthorized direct API calls.

## Performance

The application should:
- Use database indexes.
- Avoid loading all applications for every search.
- Paginate large applicant lists.
- Return only necessary fields.

## Reliability

The application should:
- Handle failed API requests.
- Provide useful errors.
- Preserve data consistency.
- Prevent invalid state transitions.

## Maintainability

The code should:
- Separate UI and business logic.
- Separate routes/controllers/services/database access.
- Use TypeScript.
- Use reusable validation schemas.
- Keep environment-specific configuration outside source code.

## Accessibility

The interface should support:
- Keyboard interaction
- Semantic markup
- Clear labels
- Visible focus
- Accessible error messages

---

# 8. Core Application Flow

```text
Student
   |
   v
Register/Login
   |
   v
Browse Societies
   |
   v
View Society
   |
   v
Apply
   |
   v
Backend Authentication
   |
   v
Backend Validation
   |
   v
Deadline Check
   |
   v
Duplicate Check
   |
   v
Database Insert
   |
   v
Pending
   |
   v
Admin Review
   |
   +----> Accepted
   |
   +----> Rejected
   |
   v
Student Sees Updated Status
```

---

# 9. Backend Architecture

Recommended structure:

```text
Request
  ↓
Route
  ↓
Authentication Middleware
  ↓
Authorization Middleware
  ↓
Validation
  ↓
Controller
  ↓
Service / Business Logic
  ↓
Repository / Prisma
  ↓
MySQL
```

The architecture prevents business rules from being implemented only in React.

---

# 10. API Requirements

## Authentication

### POST `/api/auth/register`
Creates a student account.

### POST `/api/auth/login`
Authenticates a user.

### POST `/api/auth/logout`
Ends authentication session.

### GET `/api/auth/me`
Returns current authenticated user information.

## Societies

### GET `/api/societies`
Returns available societies with optional search/filter parameters.

### GET `/api/societies/:id`
Returns society details.

### POST `/api/societies`
Admin-only creation.

### PATCH `/api/societies/:id`
Admin-only update.

### DELETE `/api/societies/:id`
Admin-only deletion subject to business rules.

## Applications

### POST `/api/applications`
Authenticated student creates application.

Server must check:
- Authentication
- Student role
- Valid society
- Active recruitment
- Deadline
- Duplicate application
- Valid application data

### GET `/api/applications/me`
Returns authenticated student's applications.

### GET `/api/applications/:id`
Returns an application only when the requester is authorized to see it.

### GET `/api/admin/societies/:id/applications`
Admin-only applicant list.

### PATCH `/api/admin/applications/:id/status`
Admin-only status update.

---

# 11. Database Design

Core entities:

```text
Users
  |
  | 1:N
  v
Applications
  ^
  | N:1
  |
Societies
```

Tables:
- users
- societies
- applications

Optional:
- audit_logs

The design must not use one flat collection for all data.

---

# 12. Validation Rules

## Registration

- Name required.
- Email required.
- Email format valid.
- Email unique.
- Password meets minimum security requirements.

## Login

- Email required.
- Password required.
- Invalid credentials return a controlled error.

## Society

- Name required.
- Description required where applicable.
- Category valid.
- Deadline valid.
- Deadline rules enforced.

## Application

- User authenticated.
- User has STUDENT role.
- Society exists.
- Society accepts applications.
- Deadline has not passed.
- Required answers supplied.
- No duplicate application.

## Status

Allowed values:
- Pending
- Accepted
- Rejected

---

# 13. Admin Security Model

An admin route must not become accessible merely because the frontend displays an admin page.

Example:

```text
GET /api/admin/applications
```

Without authentication:
```text
401 Unauthorized
```

Authenticated student:
```text
403 Forbidden
```

Authenticated admin:
```text
200 OK
```

This behavior must be demonstrable during evaluation.

---

# 14. Search and Query Design

The backend should expose query parameters such as:

```text
?search=prince
?status=Pending
?category=Technical
?societyId=123
```

The backend should translate these into database queries.

Avoid:

```text
Fetch every applicant
        ↓
Send all applicants to browser
        ↓
Filter with JavaScript
```

Prefer:

```text
Search request
      ↓
Backend query
      ↓
Database index/query
      ↓
Filtered result
```

Pagination should be considered for applicant lists.

---

# 15. Frontend Product Requirements

## Student Dashboard

Show:
- Available societies
- Application count
- Pending applications
- Recent application statuses

## Society Card

Show:
- Society name
- Category
- Short description
- Deadline
- Application status if already applied
- Apply/View button

## Application Status

Use clear visual states:
- Pending
- Accepted
- Rejected

Do not rely only on color to communicate status.

## Admin Dashboard

Show:
- Society count
- Application count
- Pending count
- Accepted count
- Rejected count

---

# 16. Error and Feedback Requirements

Every important mutation needs visible feedback.

Examples:

### Loading
"Submitting application..."

### Success
"Application submitted successfully."

### Deadline
"Applications for this society are closed."

### Duplicate
"You have already applied to this society."

### Authentication
"Please log in to continue."

### Authorization
"You are not authorized to perform this action."

### Server error
"Something went wrong. Please try again."

Do not display raw:
- SQL errors
- Stack traces
- Server filesystem paths

---

# 17. Bonus Features

## Mock Email

On application submission:
```text
Student -> Mock confirmation
```

On status update:
```text
Admin changes status
        ↓
Mock notification
        ↓
Student
```

## Analytics

Possible metrics:
- Applications per society
- Applications by category
- Applications over time
- Status distribution

## Real-Time Status

Possible implementations:
- Polling
- Socket.io/WebSockets

## Rate Limiting

Apply to:
- Login
- Registration
- Application submission

---

# 18. Success Criteria

The project successfully meets the brief when an evaluator can perform the following demonstration:

### Test 1 — Registration
Create a student account.

### Test 2 — Authentication
Log in and obtain authenticated state.

### Test 3 — Society
Admin creates a society.

### Test 4 — Application
Student applies to that society.

### Test 5 — Persistence
Refresh/restart and verify application remains.

### Test 6 — Duplicate Prevention
Student tries to apply again and is rejected.

### Test 7 — Deadline
Attempt an application after the deadline through the API and verify rejection.

### Test 8 — Student Isolation
Student attempts to access another student's application and is rejected.

### Test 9 — Admin Authorization
Student directly calls admin endpoint and receives 403.

### Test 10 — Admin Management
Admin views applicant.

### Test 11 — Status
Admin changes status to Accepted/Rejected.

### Test 12 — Student Tracking
Student sees updated status.

### Test 13 — Search
Admin searches applicant using backend query.

### Test 14 — UX
Demonstrate loading, success and error states.

---

# 19. Definition of Done

The project is done only when:

- [ ] Frontend works.
- [ ] Backend works.
- [ ] MySQL persistence works.
- [ ] Registration works.
- [ ] Login works.
- [ ] Logout works.
- [ ] Passwords are hashed.
- [ ] Student authorization works.
- [ ] Admin authorization works.
- [ ] Societies CRUD works.
- [ ] Applications are persisted.
- [ ] Students can view their own applications.
- [ ] Admins can view applicants.
- [ ] Status updates work.
- [ ] Deadline is enforced server-side.
- [ ] Duplicate applications are prevented.
- [ ] Backend validation exists.
- [ ] Frontend validation exists.
- [ ] Database relationships are correct.
- [ ] Indexes exist for important queries.
- [ ] Search/filtering is database-backed.
- [ ] Loading states exist.
- [ ] Success feedback exists.
- [ ] Error feedback exists.
- [ ] Secrets are environment variables.
- [ ] Sensitive information is not exposed.
- [ ] Protected routes fail when accessed directly without authorization.
- [ ] Core flows have been tested.
- [ ] README/documentation is complete.

---

# 20. Final Product Boundary

### Mandatory

Authentication + authorization + societies + applications + MySQL/MongoDB + backend validation + deadline enforcement + database relationships + search/filtering + UX feedback.

### Optional

Email + analytics + real-time updates + rate limiting + audit logs + additional recruitment workflows.

The mandatory requirements must be completed before optional features are prioritized.

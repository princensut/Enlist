# Recruitment Platform — Requirements Specification

## 1. Project Overview

A full-stack college society recruitment platform for Track B (2nd Year). The platform allows students to register/login, browse societies, submit applications, and track their application status. Administrators can manage societies, view applicants, and update application statuses.

The implementation must be a genuine full-stack application with:
- Backend authentication and authorization
- Persistent relational/document database
- Server-side validation
- Server-side deadline enforcement
- Admin-only and student-only backend routes
- Search/filtering with appropriate query/index design
- Interactive frontend feedback
- Secure password handling
- Clear separation between frontend, backend, database, and authorization responsibilities

## 2. Mandatory Functional Requirements

### 2.1 Authentication

Students must be able to:
- Register an account.
- Log in.
- Log out.
- Maintain an authenticated session.
- Access only their own applications.
- Submit applications while authenticated.

Passwords must:
- Never be stored in plaintext.
- Be hashed using a modern password-hashing algorithm such as Argon2id or bcrypt.
- Never be returned by APIs.
- Never be stored in localStorage as plaintext passwords.

Authentication must be enforced by the backend.

Accepted approaches:
- Secure HTTP-only cookie sessions.
- JWT-based authentication with secure storage/handling.

Frontend-only authentication is not acceptable.

### 2.2 Student Features

Students should be able to:
- Create an account.
- Log in.
- View available societies.
- View society details.
- See application deadline and eligibility information.
- Submit an application.
- View their submitted applications.
- View application status.
- Avoid duplicate applications to the same society.
- Receive clear success/error feedback.

Application statuses:
- Pending
- Accepted
- Rejected

### 2.3 Admin Features

Administrators must be able to:
- Log in through the same secure authentication system with an admin role.
- Create societies.
- Read/view societies.
- Update societies.
- Delete societies where business rules permit.
- View applicants for a society.
- Search/filter applicants.
- Update application status.
- View application details.
- Access analytics if implemented.

Admin privileges must be enforced on backend API endpoints.

### 2.4 Society Management

Each society should support fields such as:
- Society ID
- Name
- Description
- Category
- Recruitment deadline
- Active/inactive status
- Created timestamp
- Updated timestamp

Optional:
- Logo/image
- Eligibility requirements
- Contact information
- Recruitment instructions
- Maximum application capacity

### 2.5 Application Management

Each application should support:
- Application ID
- Student ID
- Society ID
- Application answers/form data
- Status
- Submission timestamp
- Last updated timestamp

The database must represent the relationship:

Student -> Applications <- Society

Applications must not be stored as an unrelated flat collection containing duplicated student and society records.

### 2.6 Validation

Validation must exist on both:
- Frontend
- Backend

Backend validation is authoritative.

The backend must reject:
- Missing required fields.
- Invalid field formats.
- Invalid IDs.
- Invalid status values.
- Applications submitted after the deadline.
- Duplicate applications where only one application per student/society is allowed.
- Unauthorized updates.
- Requests made by users without the required role.

### 2.7 Deadline Enforcement

Deadlines must be checked on the server when an application is submitted.

Disabling an Apply button in the frontend is not sufficient.

If the deadline has passed, the API must reject the request even if the user manually calls the endpoint.

### 2.8 Authorization

Minimum roles:
- STUDENT
- ADMIN

Examples:
- Student can access own applications.
- Student cannot view all applicants.
- Student cannot create/delete societies.
- Student cannot change another student's status.
- Admin can manage societies and applications.

A direct API request from an unauthenticated or wrong-role user must fail.

### 2.9 Search and Filtering

Applicant and society search/filter functionality should be implemented using database queries rather than fetching everything and filtering only in JavaScript.

Potential filters:
- Society
- Category
- Application status
- Student name
- Student email
- Submission date
- Deadline/activity status

Database indexes should be created for frequently queried fields.

### 2.10 UX Requirements

The frontend must include:
- Loading states.
- Success messages/toasts.
- Error messages/toasts.
- Form validation feedback.
- Empty states.
- Confirmation before destructive actions.
- Disabled submit state while a request is processing.
- Useful HTTP error handling.

Raw backend stack traces or unprocessed error dumps must not be shown to users.

## 3. Security Requirements

- Passwords hashed with Argon2id/bcrypt.
- Authentication enforced server-side.
- Authorization enforced server-side.
- Input validation on server.
- Database constraints for important relationships.
- Protection against duplicate applications.
- CORS configured intentionally.
- Secrets stored in environment variables.
- No database credentials committed to Git.
- No JWT secret committed to Git.
- No sensitive information exposed through frontend code.
- Rate limiting on authentication/application endpoints is recommended.
- HTTP-only, Secure and SameSite cookie settings should be used if cookie sessions are selected.
- If JWTs are used, token lifetime and refresh strategy must be explicitly designed.
- Avoid trusting role information supplied by the client.

## 4. Database Requirements

Use either:
- MySQL, or
- MongoDB.

Recommended for this project: MySQL because the student/application/society relationship is naturally relational.

Minimum logical entities:
1. Users/Students
2. Societies
3. Applications

Relationships:
- One student can submit many applications.
- One society can receive many applications.
- One application belongs to exactly one student and one society.

Important constraints:
- Unique student email.
- Unique society identifier/name as appropriate.
- Unique `(student_id, society_id)` application pair if duplicate applications are prohibited.
- Foreign keys for relationships.
- Appropriate indexes for filtering/searching.

## 5. API Requirements

Suggested endpoints:

### Authentication
- POST `/api/auth/register`
- POST `/api/auth/login`
- POST `/api/auth/logout`
- GET `/api/auth/me`

### Societies
- GET `/api/societies`
- GET `/api/societies/:id`
- POST `/api/societies` — admin
- PUT/PATCH `/api/societies/:id` — admin
- DELETE `/api/societies/:id` — admin

### Applications
- POST `/api/applications`
- GET `/api/applications/me`
- GET `/api/applications/:id`
- GET `/api/admin/applications` — admin
- GET `/api/admin/societies/:id/applications` — admin
- PATCH `/api/admin/applications/:id/status` — admin

The exact endpoint naming may change during implementation, but the underlying capabilities must remain.

## 6. Acceptance Criteria

The project is considered complete when:
- A new student can register and log in.
- Passwords are securely hashed.
- A logged-in student can submit an application.
- The application is persisted in the database.
- The student can see their application status.
- A student cannot access another student's private application data.
- An admin can create/update/delete societies.
- An admin can view applicants.
- An admin can change application status.
- A student cannot access admin endpoints.
- An unauthenticated request cannot access protected endpoints.
- A deadline cannot be bypassed through a direct API request.
- Invalid backend requests are rejected.
- Database relationships are properly represented.
- Search/filter operations use database query capabilities and indexes where appropriate.
- The UI gives loading/success/error feedback.

# Frontend Specification

## 1. Objective

Build a responsive recruitment interface that is simple for students and efficient for administrators.

The frontend must never be treated as the security layer. It should provide a good UX while the backend remains authoritative.

## 2. User Roles

### Student
Pages:
- Login
- Register
- Society listing
- Society details
- Application form
- My applications
- Application details/status
- Profile/logout

### Admin
Pages:
- Admin login/access
- Dashboard
- Society management
- Create society
- Edit society
- Applicant list
- Applicant details
- Status management
- Optional analytics

## 3. Public Pages

### Landing Page
Should explain:
- Purpose of platform
- Available recruitment
- How application works
- Login/register actions

### Society Listing
Features:
- Search
- Category filter
- Active recruitment filter
- Deadline information
- Society cards
- View details

## 4. Student Application Flow

1. Student logs in.
2. Student selects a society.
3. Student views recruitment information.
4. Student opens application form.
5. Frontend validates fields.
6. Submit button enters loading state.
7. Backend validates authentication, fields, duplicate status and deadline.
8. Success response displays confirmation.
9. Application appears in My Applications.
10. Student can monitor Pending/Accepted/Rejected status.

## 5. Application Form

Potential fields:
- Student name
- College email
- Branch/year
- Phone number if required
- Why do you want to join?
- Relevant experience
- Skills
- Portfolio/GitHub/LinkedIn if required
- Custom society-specific questions

The backend must not rely on frontend validation.

## 6. Admin Dashboard

Dashboard should show:
- Total societies
- Active recruitments
- Total applications
- Pending applications
- Accepted applications
- Rejected applications

Optional charts:
- Applications by society
- Applications by category
- Applications over time
- Status distribution

## 7. Applicant Management

Admin should be able to:
- Search applicants.
- Filter by society.
- Filter by status.
- Filter by category.
- Open applicant details.
- Change status.

Status changes:
- Pending -> Accepted
- Pending -> Rejected
- Accepted/Rejeted -> another state only if business rules permit.

Every status change must be persisted through the backend.

## 8. UX States

Every API operation should support:
- Initial state
- Loading state
- Success state
- Error state
- Empty state

Examples:
- "Submitting application..."
- "Application submitted successfully."
- "The application deadline has passed."
- "You have already applied to this society."
- "You are not authorized to perform this action."

## 9. Responsive Design

Support:
- Desktop
- Tablet
- Mobile

Admin tables should remain usable on smaller screens through:
- Horizontal scrolling
- Responsive cards
- Column prioritization

## 10. Accessibility

Use:
- Semantic HTML
- Proper labels
- Keyboard navigation
- Visible focus states
- Accessible error messages
- Sufficient contrast
- Descriptive buttons

## 11. Frontend Security Responsibilities

Frontend should:
- Never display passwords.
- Never embed secrets.
- Never decide whether an API request is authorized.
- Handle expired/invalid authentication gracefully.
- Avoid trusting role values supplied by local storage.

## 12. API Service Layer

Keep API calls outside UI components where practical.

Example organization:

```text
services/
├── authService.ts
├── societyService.ts
├── applicationService.ts
└── adminService.ts
```

## 13. State Management

For this project, React Context or a lightweight state library is sufficient.

Avoid unnecessary global state.

Server data should be refreshed after important mutations.

## 14. Error Handling

Convert backend errors into human-readable messages.

Do not expose:
- SQL errors
- Stack traces
- Internal file paths
- Secret values
- Database connection details

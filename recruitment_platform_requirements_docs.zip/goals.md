# Project Goals

## 1. Primary Goal

Build a production-style full-stack recruitment platform that demonstrates that the team understands authentication, authorization, persistent data, relational data modeling, server-side validation and practical frontend UX.

## 2. Core Technical Goals

### Authentication
Demonstrate secure registration, login, logout and session handling.

### Authorization
Demonstrate real backend role-based access control.

### Persistence
Store users, societies and applications in a real database.

### Data Modeling
Represent actual relationships instead of using one flat data collection.

### Validation
Implement validation on both frontend and backend.

### Business Rules
Enforce recruitment deadlines and duplicate-application rules on the server.

### Query Design
Use database filtering, searching and indexes instead of downloading all records and filtering in frontend code.

### UX
Provide immediate feedback for important actions.

## 3. Student Goals

Students should be able to:
- Register easily.
- Log in securely.
- Discover societies.
- Understand recruitment requirements.
- Apply without confusion.
- Track their applications.
- Understand status changes.

## 4. Admin Goals

Administrators should be able to:
- Manage societies.
- Monitor applicants.
- Search/filter efficiently.
- Review application information.
- Change application status.
- Monitor recruitment activity.

## 5. Quality Goals

The system should be:
- Secure
- Maintainable
- Responsive
- Testable
- Understandable
- Scalable enough for college-level recruitment
- Easy to demonstrate

## 6. Demonstration Goals

The final demo should be able to prove:

1. Student registration works.
2. Password is hashed.
3. Student login creates an authenticated session.
4. Student can apply.
5. Application is stored in database.
6. Deadline is enforced by backend.
7. Duplicate application is prevented.
8. Student cannot access admin data.
9. Admin can manage societies.
10. Admin can view applicants.
11. Admin can update status.
12. Student sees updated status.
13. Search/filter uses database queries.
14. UI provides loading and error feedback.

## 7. Bonus Goals

If time permits:
- Mock email confirmations.
- Analytics dashboard.
- Real-time status updates.
- Polling.
- Socket.io.
- Rate limiting.
- Audit log.
- Export applicants to CSV.
- Society-specific application forms.
